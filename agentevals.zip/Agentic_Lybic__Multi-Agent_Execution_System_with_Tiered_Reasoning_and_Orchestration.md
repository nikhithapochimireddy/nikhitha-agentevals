# Agentic Lybic: Multi-Agent Execution System with Tiered Reasoning and Orchestration

###### **Abstract.**

Autonomous agents for desktop automation struggle with complex multi-step tasks due to poor coordination and inadequate quality control. We introduce Agentic Lybic, a novel multi-agent system where the entire architecture operates as a finite-state machine (FSM). This core innovation enables dynamic orchestration. Our system comprises four components: a Controller, a Manager, three Workers (Technician for code-based operations, Operator for GUI interactions, and Analyst for decision support), and an Evaluator. The critical mechanism is the FSM-based routing between these components, which provides flexibility and generalization by dynamically selecting the optimal execution strategy for each subtask. This principled orchestration, combined with robust quality gating, enables adaptive replanning and error recovery. Evaluated officially on the OSWorld benchmark, Agentic Lybic achieves a state-of-the-art 57.07% success rate in 50 steps, substantially outperforming existing methods. Results demonstrate that principled multi-agent orchestration with continuous quality control provides superior reliability for generalized desktop automation in complex computing environments.

Multi-agent systems, Desktop GUI automation, Task orchestration, Autonomous agents coordination

†journalyear: 2026

†copyright: cc

†conference: CHI Conference on Human Factors in Computing Systems; April 13–17, 2026; Creant el demà junts, Barcelona

†booktitle: CHI Conference on Human Factors in Computing Systems (CHI ’26), April 13–17, 2026, Creant el demà junts, Barcelona

†isbn: 978-1-4503-XXXX-X/2026/04

†ccs: Computing methodologies Multi-agent systems

†ccs: Computing methodologies Multi-agent planning

†ccs: Software and its engineering Layered systems

†ccs: Human-centered computing Graphical user interfaces

Figure 1.Overview of the Agentic Lybic multi-agent system architecture.

\Description

The Manager decomposes user queries into subtasks using DAG planning. Specialized Workers (Operator, Technician, Analyst) execute actions through the Executor, while the Evaluator provides continuous quality monitoring. The Global State maintains system information and enables dynamic coordination between components.

## **1.Introduction**

The automation of complex desktop tasks through autonomous agents represents one of the most challenging frontiers in artificial intelligence, requiring systems that can navigate intricate multi-step workflows while maintaining reliability and efficiency(Zhang et al., [2025a](https://arxiv.org/html/2509.11067v1#bib.bib43); Nguyen et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib20)). Recent advances in computer-using agents have demonstrated promising capabilities in executing tasks through Graphical User Interfaces (GUIs), with vision-language models enabling increasingly sophisticated interactions with visual elements(Deepmind, [2025](https://arxiv.org/html/2509.11067v1#bib.bib8); OpenAI, [2025b](https://arxiv.org/html/2509.11067v1#bib.bib23), [2024](https://arxiv.org/html/2509.11067v1#bib.bib21), [a](https://arxiv.org/html/2509.11067v1#bib.bib22); Qin et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib24)). Current approaches to desktop automation typically fall into two categories: GUI-centric agents that rely exclusively on visual interaction(Agashe et al., [2025a](https://arxiv.org/html/2509.11067v1#bib.bib3); Yang et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib38)), and hybrid systems that combine GUI manipulation with programmatic execution. While GUI-only agents offer intuitive human-like interaction patterns, they suffer from brittleness in complex scenarios due to visual grounding ambiguity and accumulated error propagation over long sequences. Recent hybrid approaches, such as CoAct-1(Song et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib26)), have addressed some of these limitations by introducing specialized programming agents alongside GUI operators, achieving notable improvements in both efficiency and success rates. However, these systems’ core limitation lies in their handling of long-horizon tasks. They often employ a simplistic ”delegate-and-forget” approach, which lacks the continuous oversight and adaptive re-planning needed for robust error recovery. Consequently, they fail to implement the sophisticated routing mechanisms and comprehensive quality control essential for coordinating multiple functional modules over extended workflows.

The core challenge lies not merely in expanding the action space of computer-using agents, but in orchestrating multiple specialized components through principled coordination mechanisms that can dynamically adapt to changing task requirements and handle execution failures gracefully(Tallam, [2025](https://arxiv.org/html/2509.11067v1#bib.bib28)). Existing systems often treat task decomposition and execution as separate phases, lacking the continuous feedback loops necessary for robust long-horizon performance(Hu et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib11)). Furthermore, current quality assessment approaches are typically binary and reactive, missing opportunities for proactive intervention(Sun et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib27)) and incremental course correction.

To address these issues above, we draw inspiration from finite-state machines (FSMs), which provide a structured and predictable framework for managing complex, state-dependent workflows. In this work, we introduce **Agentic Lybic**, a novel FSM-based multi-agent execution system, which could addresse these fundamental limitations through a tiered reasoning architecture and sophisticated orchestration framework. Our system advances beyond simple hybrid execution by implementing a comprehensive four-tier architecture: a **Controller** that manages global state and decision triggers, a **Manager** for intelligent task decomposition and adaptive re-planning, a **Worker** subsystem with three specialized roles (Technician for system operations, Operator for GUI interactions, and Analyst for decision support), and an **Evaluator** that provides continuous quality assessment and intervention triggers.

The key innovation of our approach lies in the dynamic orchestration mechanism (i.e., routing) that seamlessly coordinates between different functional modules based on ongoing task assessment, coupled with a comprehensive quality gate system that enables persistent monitoring, adaptive re-planning, and robust error recovery. Unlike existing systems that perform static task delegation, Agentic Lybic implements a feedback-driven execution model where performance is continuously monitored through multiple trigger mechanisms (periodic checks, stagnation detection, and success verification), enabling the system to adaptively adjust its strategy mid-execution.

Our tiered reasoning approach introduces several novel contributions: (1) a state-aware orchestration framework that dynamically selects optimal execution strategies based on task characteristics and current system state, (2) a comprehensive quality gate system with multiple intervention triggers that enable proactive error handling and adaptive re-planning, (3) a specialized worker architecture that provides fine-grained control over different execution modalities while maintaining seamless coordination, and (4) an incremental clarification policy that systematically addresses visual ambiguity in GUI-dense environments.

We evaluate Agentic Lybic on the challenging OSWorld benchmark, where our system achieves a new state-of-the-art success rate of 57.07% in 50 steps, representing a substantial improvement over existing methods including the recent CoAct-1 (Song et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib26)) (56.4%) and agent s2.5 (Agashe et al., [2025a](https://arxiv.org/html/2509.11067v1#bib.bib3)) (54.2%). Beyond raw performance gains, our system demonstrates superior reliability in long-horizon scenarios and maintains efficiency through proactive quality control. Our results demonstrate that principled multi-agent orchestration with continuous quality assessment provides a more robust and scalable foundation for generalized desktop automation, opening new possibilities for autonomous task execution in complex computing environments. The tiered reasoning approach not only improves success rates but also provides a systematic framework for handling the inherent complexity and uncertainty of real-world desktop automation tasks.

## **2.Related Work**

### **2.1.Screen Understanding and Visual Grounding**

A foundational challenge in GUI automation lies in accurately perceiving and grounding interface elements from raw pixel input. Early approaches focused on developing sophisticated screen parsing capabilities that could identify and locate interactive elements without relying on structured representations like DOM trees or accessibility hooks(Lai et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib13)). OmniParser (Lu et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib18); Yu et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib41)) pioneered this direction by learning screen-parsing primitives for pure vision-based understanding, enhancing the ability of large models to generate accurate actions in interface regions through interactive icon detection and semantic element extraction.

The grounding problem—mapping natural language instructions to actionable screen locations—has been addressed through several specialized systems. SeeClick introduced instruction-to-target grounding capabilities (Cheng et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib7)), while Aria-UI (Yang et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib39)) and UGround (Gou et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib9)) extended this to universal GUI grounding across diverse interfaces. OS-Atlas (Wu et al., [2024c](https://arxiv.org/html/2509.11067v1#bib.bib33)) represents a major advance in this area, training a foundation action model that generalizes across multiple platforms (Windows, Linux, MacOS, Android, and web) using a massive corpus of over 13 million GUI elements. The system demonstrates how large-scale, cross-platform training data can substantially improve GUI grounding performance, particularly in out-of-distribution scenarios. ScreenSpot-Pro (Li et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib15)) provides dedicated grounding evaluation benchmarks under professional, high-resolution settings, addressing the growing need for robust performance assessment in complex visual environments.

### **2.2.End-to-End GUI Agents**

The end-to-end paradigm represents a paradigmatic shift toward unified models that integrate perception, reasoning, and action generation within a single model. These approaches aim to eliminate the need for separate planning and grounding components by training models that can directly predict executable actions from visual input and high-level instructions.

CogAgent (Hong et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib10)) exemplifies this approach as an 18B parameter visual language model specifically designed for GUI understanding and navigation. By utilizing both low-resolution and high-resolution image encoders, CogAgent supports input at 1120×1120 resolution, enabling recognition of tiny page elements and text. The model achieves state-of-the-art performance on multiple text-rich and general VQA benchmarks while outperforming LLM-based methods on both PC and Android GUI navigation tasks using only screenshots as input. More recently, GUI-Owl (Ye et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib40)) has pushed the boundaries of end-to-end GUI agents through three key innovations: large-scale environment infrastructure enabling self-evolving trajectory production, diverse foundational agent capabilities integrating UI grounding with planning and reasoning, and scalable environment reinforcement learning for real-world alignment. GUI-Owl-7B achieves impressive performance scores of 66.4 on AndroidWorld and 29.4 on OSWorld, demonstrating the potential of purpose-built foundational models for GUI automation.

UI-TARS (Qin et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib24)) represents a native end-to-end GUI agent model that processes raw screenshots and generates human-like interactions through unified perception, reasoning, action, and memory capabilities. The system integrates enhanced visual understanding through large-scale GUI datasets, unified action modeling across platforms, System-2 reasoning with explicit thought generation, and iterative refinement via online trace collection. UI-TARS-2 (Wang et al., [2025b](https://arxiv.org/html/2509.11067v1#bib.bib30)) further advances this approach through multi-turn reinforcement learning and hybrid GUI environments that combine screen actions with file system access. AGUVIS (Xu et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib37)) and InfiGUIAgent (Liu et al., [2025a](https://arxiv.org/html/2509.11067v1#bib.bib16)) enhance GUI agent autonomy through unified visual frameworks, with InfiGUIAgent introducing a two-stage training pipeline that advances GUI task automation using inner monologue techniques. GUI-R1 (Luo et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib19)) demonstrates how rule-based reinforcement fine-tuning can enhance high-level GUI action prediction while achieving competitive performance with considerably less training data. InfiGUI-R1 (Liu et al., [2025b](https://arxiv.org/html/2509.11067v1#bib.bib17)) shifts agents from reactive acting to deliberative reasoning through reasoning spatial distillation and reinforcement learning approaches.

Recent work has also focused on addressing temporal dynamics and action prediction capabilities. ScaleTrack (Huang et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib12)) predicts future actions from current GUI images and backtracks historical actions, thereby explaining the evolving correspondence between GUI elements and actions. UITron-Speech (Zeng et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib42)) extends beyond text-based instructions by introducing the first end-to-end GUI agent capable of processing speech instructions directly, utilizing mixed-modality training strategies and two-step grounding refinement to handle the inherent challenges of speech-driven interface interaction.

### **2.3.Multi-Agent Frameworks**

While end-to-end models show promise for unified GUI interaction, agentic frameworks focus on orchestrating multiple specialized components to leverage complementary strengths and achieve more robust performance on complex tasks. These systems typically separate high-level planning from low-level execution while introducing sophisticated coordination mechanisms. The modular planner-grounder paradigm explicitly separates ”what to do” from ”where and how to act on screen.” Representative systems like SeeClick (Cheng et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib7)) and OS-Atlas (Wu et al., [2024b](https://arxiv.org/html/2509.11067v1#bib.bib34)) demonstrate how language planners can propose subgoals while visual models handle grounding. GTA-1 (Yang et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib38)) strengthens this approach through test-time scaling, sampling multiple candidate actions and using multimodal large language model (MLLM) judges for selection, improving robustness on high-resolution, cluttered interfaces.

CoAct-1 (Song et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib26)) represents the most recent advance in hybrid agentic frameworks, introducing a paradigm where agents can use coding as an enhanced action modality. The system features an Orchestrator that dynamically delegates subtasks between a GUI Operator and a specialized Programmer agent capable of writing and executing Python or Bash scripts. This hybrid approach demonstrates substantial performance improvements by leveraging the complementary strengths of GUI manipulation and programmatic execution, achieving state-of-the-art results on the OSWorld benchmark.

Beyond GUI-specific systems, several frameworks provide general infrastructure for multi-agent orchestration and tool composition. Agent-S/Agent-S2 (Agashe et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib2), [2025b](https://arxiv.org/html/2509.11067v1#bib.bib4)) and AutoGen (Wu et al., [2024a](https://arxiv.org/html/2509.11067v1#bib.bib32)) offer reusable infrastructures for multi-agent coordination and tool calling. UFO-2 (Zhang et al., [2025b](https://arxiv.org/html/2509.11067v1#bib.bib44)), PyVision (Zhao et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib45)), and ALITA (Qiu et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib25)) extend this principle to dynamic tool construction and invocation, though they are not specifically designed for GUI automation.

While these agentic frameworks have made significant progress in combining different execution modalities, they often lack sophisticated quality control mechanisms and continuous oversight capabilities. Most systems treat task decomposition and execution as largely separate phases, missing opportunities for adaptive re-planning and proactive error correction that are essential for robust long-horizon performance. Our work addresses these limitations through a self-consistent FSM-based tiered reasoning architecture with continuous quality assessment and dynamic orchestration capabilities.

## **3.Agentic Lybic: FSM-based Multi-Agent Architecture**

In this section, we present the detailed design of Agentic Lybic. Our system transcends traditional approaches by implementing a four-tier architecture with continuous quality control and adaptive re-planning mechanisms, which is the core of state transition of the FSM.

### **3.1.System Architecture Overview**

Agentic Lybic is built upon a hierarchical four-component architecture designed to maximize coordination efficiency while maintaining robust execution control (Figure [2](https://arxiv.org/html/2509.11067v1#S3.F2)). The system comprises: (1) a **Controller** that manages global state transitions and decision triggers, (2) a **Manager** responsible for intelligent task decomposition and adaptive re-planning, (3) a **Worker** subsystem with three specialized execution roles, and (4) an **Evaluator** that provides continuous quality assessment and intervention mechanisms.

The key innovation lies in our state-driven orchestration framework (i.e., state transition), where each component operates within a well-defined state space that enables seamless coordination and robust error handling. Unlike existing systems that rely on simple delegation patterns, our architecture implements a continuous feedback loop with multiple quality gates that enable proactive intervention and adaptive strategy adjustment.

Figure 2.State transition diagram of Agentic Lybic showing the tiered orchestration workflow. The Central Controller manages six core situations (REPLAN, SUPPLEMENT, GET ACTION, QUALITY CHECK, FINAL CHECK, EXECUTE ACTION) with dynamic transitions based on execution outcomes. The Manager handles task decomposition and re-planning, the Worker subsystem provides specialized execution through three roles (Operator for GUI, Technician for system operations, Analyst for decision support), and the Evaluator implements comprehensive quality gates with multiple trigger mechanisms (periodic checks, stagnation detection, success verification).

### **3.2.Central Controller: State Management and Decision Orchestration**

The Controller serves as the central nervous system of our architecture, managing global state transitions and orchestrating component interactions through a sophisticated state machine. We define six primary controller situations that capture the essential phases of task execution:

- • **REPLAN (Rp)**: Triggered when task initial decomposition or strategy adjustment is required

- • **SUPPLEMENT (Sp)**: Activated when additional contextual information from Web or external knowledge base is needed

- • **GET_ACTION (Ga)**: Gets specific action generation by Worker components

- • **QUALITY_CHECK (Qc)**: Evaluates execution effectiveness and determines continuation strategy

- • **FINAL_CHECK (Fc)**: Performs comprehensive task completion verification

- • **EXECUTE_ACTION (Ea)**: Coordinates actual operation execution through the hardware interface

The Controller maintains a comprehensive state space that encompasses task-level status (created, pending, on_hold, fulfilled, rejected), subtask-level progress (ready, pending, stale, fulfilled, rejected), and execution-level outcomes (executed, timeout, blocked, error). This multi-granular state representation enables fine-grained control over the execution process while providing robust error handling capabilities.

Formally, we define the global state as a tuple S=(ST,SS​T,SE,C), where ST represents task status, SS​T denotes subtask status, SE captures execution status, and C indicates the current controller situation. The state transition function is defined as:

Markdown

| (1) |  | St+1=δ​(St,At,Ot) |  |
| --- | --- | --- | --- |

where At represents the action taken at time t, Ot is the observation received, and δ is the state transition function (i.e., the whole Agentic Lybic system) that determines the next state based on current context and execution outcomes.

The Controller employs a trigger code system (i.e., a state transition look-up-table) organized into ten primary categories that enable precise coordination between components and robust error handling (see Table [A.1](https://arxiv.org/html/2509.11067v1#A1.T1) for complete reference). This trigger-driven architecture encompasses: Rule Validation triggers for automated quality control (periodic checks, stagnation detection, execution limits), Task Status Rules for system-wide oversight and resource management (completion detection, runtime limits, state switch boundaries), Worker Coordination triggers for managing the interface between planning and execution across all three Worker roles, and Error Recovery mechanisms for graceful degradation under unexpected conditions. The comprehensive trigger system ensures that Agentic Lybic maintains precise control over execution flow while providing the flexibility necessary for handling diverse desktop automation scenarios, with each trigger category contributing to different aspects of system reliability and coordination effectiveness.

### **3.3.Manager: Task Decomposition and Adaptive Re-planning**

The Manager component implements advanced planning capabilities that go beyond simple task decomposition. Followed by Agent-S/Agent-S2 (Agashe et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib2), [2025b](https://arxiv.org/html/2509.11067v1#bib.bib4)), it employs a directed acyclic graph (DAG) representation for subtask dependencies, enabling sophisticated scheduling and parallel execution opportunities. The Manager’s core responsibilities include:

**Objective Alignment**: The Manager begins by analyzing the user’s high-level intent and aligning it with the current visual context captured through screenshots. This alignment process disambiguates user queries by grounding abstract intentions in the concrete desktop environment, identifying available applications, current system state, and potential execution pathways.

**Initial Planning Generation**: Following objective alignment, the Manager generates a comprehensive initial plan containing all necessary subtasks to achieve the user’s goal. This initial planning phase creates subtask specifications without dependency constraints, focusing on completeness and task coverage.

**DAG Construction**: The Manager then transforms the initial plan into a directed acyclic graph (DAG) representation with explicit structure:

- • **NODES**: Each node contains a subtask title, detailed description, and assigned worker role (Technician for system operations, Operator for GUI interactions, or Analyst for decision support)

- • **EDGES**: Directed connections between nodes representing execution dependencies and precedence constraints

Based on the DAG structure, the Manager performs topological sorting to generate the actual execution sequence, ensuring subtask execution respects dependency constraints while identifying opportunities for parallel execution.

**Adaptive Planning**: The system implements dynamic planning adjustment through structured prompting strategies rather than mathematical optimization. The adjustment mechanism employs three levels: (1) *light adjustment* for parameter modifications within existing subtasks, (2) *medium adjustment* for subtask reordering and dependency restructuring, and (3) *heavy adjustment* for complete task re-decomposition when fundamental strategy changes are required. These adjustments are triggered by execution feedback and implemented through carefully crafted prompt templates that guide the Manager toward appropriate planning modifications.

**Supplement Integration**: The Manager incorporates a supplement mechanism that leverages external knowledge sources (web search, Retrieval-Augmented Generation (RAG) systems) to enhance task understanding and fill information gaps. This capability is particularly crucial for handling novel scenarios or domain-specific requirements that may not be covered in the base knowledge.

### **3.4.Worker Subsystem: Specialized Multi-Modal Execution**

The Worker subsystem represents a significant advancement over traditional single-modality approaches by implementing three specialized execution roles, each optimized for specific types of operations:

**Operator**: Manages GUI-based interactions using vision-language models for visual grounding and action generation. The Operator excels in scenarios requiring human-like interface navigation, form filling, visual content interpretation, and any tasks where GUI interaction is the primary or only available interface. It implements sophisticated visual grounding techniques to handle dense GUI environments and maintains context awareness across multi-step interaction sequences.

The Operator supports a comprehensive action repertoire including fundamental mouse operations (Click, DoubleClick, Move, Drag), keyboard interactions (TypeText, Hotkey), navigation controls (Scroll, SwitchApplications), and specialized functions for different contexts (SetCellValues for spreadsheets, Open for file operations). Additionally, it provides system coordination capabilities through Screenshot for visual state capture, Wait for timing control, and a unique Memorize function that enables cross-component information sharing by writing contextual memories to shared artifacts for other modules to access. Task completion is managed through explicit Done and Failed signals that trigger appropriate state transitions in the orchestration framework.

**Technician**: Handles system-level operations through terminal commands and script execution. The Technician is particularly effective for file system operations, environment configuration, batch processing, and any tasks that can be accomplished more reliably through programmatic interfaces than GUI manipulation. It supports both Python and Bash scripting environments and implements secure execution boundaries to prevent system compromise.

**Analyst**: Provides decision support and analytical capabilities for complex reasoning tasks. The Analyst is particularly essential for complex workflows where the Operator alone cannot complete the full task sequence—such as examination or assessment scenarios where questions must first be collected, analyzed, and answered before responses can be input. In these multi-stage workflows, the Operator first captures question content and writes it to shared artifacts, the Analyst retrieves this information from artifacts to perform reasoning and generate answers, then writes the solutions back to artifacts, enabling the Operator to subsequently extract and input the final answers. This artifact-mediated collaboration allows the system to handle sophisticated question-answering tasks that require separation of perception, reasoning, and action phases.

### **3.5.Evaluator: Continuous Quality Assessment and Intervention**

The Evaluator component implements a comprehensive quality control framework that represents one of our key innovations. Unlike traditional binary success/failure assessments, our Evaluator provides continuous monitoring with multiple intervention triggers:

**Gate Decision Framework**: The Evaluator employs a comprehensive gate decision mechanism with four possible outcomes: gate_done (subtask completed successfully), gate_fail (execution failed, requires re-planning), gate_continue (execution in progress, continue current strategy), and gate_supplement (additional information needed).

**Multi-Trigger Quality Assessment**: The system implements three distinct trigger mechanisms for quality evaluation:

- • *PERIODIC_CHECK*: Regular assessment every 5 execution steps to ensure consistent progress and stagnation detection when identical actions are repeated more than 3 times or single subtask execution exceeds 15 actions.

- • *WORKER_STALE*: Triggered when workers report they are unable to determine how to continue execution.

- • *WORKER_SUCCESS*: Verification trigger when workers report task completion.

The gate decision function processes these triggers through a comprehensive evaluation:

| (2) |  | G​(s,vt,vt−1)={gate_doneif similarity​(vt,vt​a​r​g​e​t)>τd​o​n​egate_failif progress​(vt,vt−1)<τf​a​i​lgate_continueif ​τf​a​i​l≤progress​(vt,vt−1)<τd​o​n​egate_supplementif uncertainty​(s)>τs​u​p​p​l​e​m​e​n​t |  |
| --- | --- | --- | --- |

where vt represents the current visual state, vt​a​r​g​e​t is the expected target state, and s denotes the current system state. All these functions described above (e.g., similarity​(⋅,⋅)) are all served by the Evaluator role.

**Final Check Verification**: The Evaluator implements a comprehensive final verification mechanism that activates when all subtasks reach completion status, serving as the ultimate quality gate before task termination. This final check performs holistic assessment beyond individual subtask verification, examining whether the combined execution results satisfy the user’s original intent. The system supports five outcomes: final_check_passed (successful completion), final_check_failed (objectives unmet, triggers re-planning), final_check_pending (additional work discovered), final_check_error (verification error, triggers termination), and task_impossible (clean termination for intractable tasks).

### **3.6.Workflow Orchestration and State Transitions**

As illustrated in Figure [2](https://arxiv.org/html/2509.11067v1#S3.F2), our Agentic Lybic system operates through a self-consistent state-driven workflow that orchestrates seamless coordination between its four core components. The workflow begins when a user query enters the system, triggering the Central Controller to initialize the global state and enter the main execution pipeline.

**Initialization and Planning Phase**: Upon receiving a user query, the Controller sets the task state to ”created” and transitions to the REPLAN situation (Rp). The Manager performs objective alignment to understand the user’s intent, then conducts dynamic task planning to decompose the goal into executable subtasks. Using DAG generation, the Manager creates a structured plan where subtasks are organized with explicit dependencies. The Rule Engine monitors this process, ensuring planning attempts remain within configured limits (default: 10 attempts).

**Action Generation and Execution Cycle**: Once subtasks are available, the Controller transitions to GET_ACTION (Ga). The Worker subsystem receives role assignments based on subtask characteristics—Operator for GUI interactions, Technician for system operations, or Analyst for decision support. Each Worker generates specific actions appropriate to their domain expertise. When Workers generate actual executable actions (such as Click, TypeText, or system commands), the Controller transitions to EXECUTE_ACTION (Ea), where the Executor component coordinates hardware-level operation execution. However, when Workers return decision signals (CANNOT_EXECUTE, SUPPLEMENT, STALE, or DONE), the Controller transitions to appropriate states based on the specific decision: CANNOT_EXECUTE triggers REPLAN, SUPPLEMENT activates SUPPLEMENT state, STALE leads to QUALITY_CHECK, and DONE proceeds to QUALITY_CHECK for verification.

**Continuous Quality Monitoring**: After each execution step, the system enters QUALITY_CHECK (Qc) through multiple trigger mechanisms. The Evaluator employs three distinct triggers: periodic assessment every 5 steps, stagnation detection when identical actions repeat more than 3 times, and verification when Workers report task completion. The gate decision framework processes visual state comparisons and progress analysis to determine one of five outcomes: gate_done (continue to next subtask), gate_fail (trigger re-planning), gate_continue (maintain current strategy), gate_supplement (request additional information), or gate_error (handle evaluation errors and trigger appropriate recovery mechanisms).

**Adaptive Coordination and Recovery**: When gate_supplement is triggered, the Controller transitions to SUPPLEMENT (Sp), where the Manager queries external knowledge sources or requests clarification. Failed quality checks return the system to REPLAN, enabling the Manager to perform light, medium, or heavy adjustments based on failure severity. This adaptive mechanism allows the system to modify parameters, restructure dependencies, or completely re-decompose tasks as needed.

**Completion and Verification**: When all subtasks reach completion status, the Controller enters FINAL_CHECK (Fc). The Evaluator performs comprehensive verification against the original objectives, ensuring all task requirements have been satisfied. Only upon successful final verification does the system transition to the terminal DONE state, marking task fulfillment.

The workflow implements robust error handling through state recovery mechanisms. Invalid states trigger transitions to INIT for system reset, while execution errors redirect to appropriate recovery paths. This design ensures the system maintains operational stability even when individual components encounter failures, providing graceful degradation rather than complete system breakdown. The Rule Engine continuously monitors system health through configurable thresholds: maximum state switches (default: 100), task runtime limits, and execution step boundaries. These safeguards prevent infinite loops and ensure resource-bounded operation while maintaining execution flexibility for complex tasks.

## **4.Results**

Table 1.Comparison of the state-of-the-art methods on the OSWorld (Xie et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib36)) benchmark. We show the approach type in the second column. A specialized model means that the model is trained specifically for computer use. We report the success rate (%) as the evaluation metric in the third column. We only include the verified results from [https://os-world.github.io/](https://os-world.github.io/).

| **      Agent Model** | **      Approach Type** | **      Success Rate** |
| --- | --- | --- |
| **      *****50 steps*** |
| **      o3 (OpenAI,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib23)[**2025b**](https://arxiv.org/html/2509.11067v1#bib.bib23)**)** | General Model | 17.17 |
| **      opencua-a3b (Wang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib31)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib31)**)** | Specialized model | 19.93 |
| **      opencua-qwen2-7b (Wang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib31)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib31)**)** | Specialized model | 20.60 |
| **      UI-TARS-72B-DPO (Qin et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib24)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib24)**)** | Specialized Model | 25.80 |
| **      Jedi-7B w/ gpt-4o (Xie et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib35)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib35)**)** | Agentic Framework | 26.92 |
| **      UI-TARS-1.5-7B (Qin et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib24)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib24)**)** | Specialized Model | 27.30 ± 2.1 |
| **      opencua-7b (Wang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib31)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib31)**)** | Specialized model | 28.20±0.5 |
| **      TianXi-Action-7B (Tang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib29)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib29)**)** | Specialized model | 29.80±0.6 |
| **      OpenAI CUA 4o (OpenAI,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib23)[**2025b**](https://arxiv.org/html/2509.11067v1#bib.bib23)**)** | Specialized Model | 31.30 |
| **      opencua-32b (Wang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib31)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib31)**)** | Specialized Model | 34.10 ± 0.7 |
| **      claude-3-7-sonnet-20250219 (Anthropic,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib5)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib5)**)** | General Model | 35.80 |
| **      claude-4-sonnet-20250514 (Anthropic,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib6)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib6)**)** | General Model | 43.90 |
| **      Agent S2 w/ Gemini-2.5-Pro (Agashe et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib3)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib3)**)** | Agentic Framework | 45.76 |
| **      autoglm-os-9b (Lai et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib14)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib14)**)** | Specialized model | 47.26 |
| **      GTA-1-7B w/ o3 (Yang et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib38)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib38)**)** | Agentic Framework | 48.59 |
| **      Jedi-7B w/ o3 (Xie et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib35)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib35)**)** | Agentic Framework | 50.65 |
| **      Agent S2.5 w/ o3 (Agashe et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib3)[**2025a**](https://arxiv.org/html/2509.11067v1#bib.bib3)**)** | Agentic Framework | 54.21 |
| **      CoACT-1 w/ o3 (Song et al.,**[** **](https://arxiv.org/html/2509.11067v1#bib.bib26)[**2025**](https://arxiv.org/html/2509.11067v1#bib.bib26)**)** | Agentic Framework | 56.39 |
| **      Agentic Lybic w/ o3 ****&**** UI-TARS** | Agentic Framework | **57.07** |

### **4.1.Experimental Setup**

**Benchmark and Dataset.** We evaluate Agentic Lybic on the OSWorld benchmark (Xie et al., [2024](https://arxiv.org/html/2509.11067v1#bib.bib36)), a scalable real-computer testbed that exposes a Linux OS environment to agents through both pixel streams and shell interfaces. OSWorld comprises 361 tasks (excluding Google Drive tasks) spanning common productivity tools, IDEs, browsers, file managers, and multi-application workflows, providing comprehensive coverage of vision-language grounding and long-horizon planning challenges in heterogeneous GUI environments. Each task includes: (i) a deterministic VM snapshot capturing the initial desktop state, (ii) natural-language goals mirroring end-user requests (e.g., ”resize the image to 512×512 and export as PNG”), and (iii) rule-based evaluators built from 134 atomic execution-based components. Tasks range from atomic operations to complex cross-application pipelines, offering a realistic spectrum of automation complexity.

**Implementation Details.** We implement Agentic Lybic with careful selection of backbone models for each component. For all core reasoning components (Controller, Manager, and the three Worker roles - Technician, Operator, and Analyst), we utilize OpenAI o3 (OpenAI, [2025b](https://arxiv.org/html/2509.11067v1#bib.bib23)) to leverage its advanced reasoning capabilities for complex task orchestration and decision-making. For visual grounding and GUI action generation within the Operator worker, we employ UI-TARS (Qin et al., [2025](https://arxiv.org/html/2509.11067v1#bib.bib24)), a specialized vision-language model specifically fine-tuned for computer use tasks and GUI element recognition. The Evaluator component also uses o3 for comprehensive quality assessment and gate decision-making. Our system operates with carefully tuned limits: quality checks triggered every 5 execution steps, stagnation detection after 3 consecutive identical actions, and re-planning triggered when single subtask execution exceeds 15 actions. Our implementation is publicly available at [https://github.com/xlang-ai/OSWorld/tree/main/mm_agents/maestro](https://github.com/xlang-ai/OSWorld/tree/main/mm_agents/maestro) to facilitate reproducibility and future research. The OSWorld official held the evaluation process and reported the verified result Success Rate.

**Evaluation Protocol.** We employ the rule-based evaluator provided by OSWorld, which expresses each task as Boolean expressions built from the 134 atomic evaluators. Task completion requires satisfying complex logical conditions (e.g., (file exported AND MD5 matches) AND (email sent == True)), ensuring comprehensive verification of task objectives rather than superficial completion signals.

Table 2. Per-task performance comparison on OSWorld tasks with 50 steps budget. The number beside each subtask is the total number of that subtask. It is obvious that Agentic Lybic outperforms the previous SOTA methods in almost all subtasks and achieves the best overall average performance. Subtasks with the most performance gain are Chrome, Impress, GIMP, and OS, demonstrating the effectiveness of our framework.

| **Methods (50 steps)** | **Chrome (46)** | **Calc (47)** | **Impress (47)** | **Writer (23)** | **GIMP (26)** | **VSCode (23)** | **Multi Apps (93)** | **Thunderbird (15)** | **OS (24)** | **VLC (17)** | **Avg.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **autoglm-os** | 36.96 | 58.70 | 27.57 | 52.17 | 57.69 | 69.57 | 33.43 | 80.00 | 66.67 | 64.29 | 47.26 |
| **GTA-1** | 34.78 | 40.43 | 44.60 | 60.74 | 73.08 | **82.61** | 37.05 | **86.67** | 58.33 | 35.47 | 48.59 |
| **Jedi-7B** | 57.69 | 40.43 | 44.66 | 65.22 | 80.77 | 56.52 | 34.97 | 80.00 | 54.17 | 58.06 | 50.65 |
| **Agent S2.5** | 52.09 | 55.32 | 55.30 | 47.83 | 76.92 | 73.91 | 39.53 | 73.33 | 75.00 | 42.00 | 54.21 |
| **CoACT-1** | 45.57 | **68.09** | 46.72 | **73.91** | 61.54 | 78.26 | **42.37** | 66.67 | 70.83 | **66.06** | 56.39 |
| **Agentic Lybic** | **60.78** | 51.06 | **59.48** | 69.56 | **84.62** | 73.91 | 35.56 | 73.33 | **79.17** | 63.75 | **57.07** |

### **4.2.Main Results**

[Table 1](https://arxiv.org/html/2509.11067v1#S4.T1) presents comprehensive performance comparisons on OSWorld, demonstrating that Agentic Lybic establishes new state-of-the-art results across multiple evaluation settings. Our system achieves a remarkable success rate of **57.07%** at 50 steps, substantially outperforming all existing methods including CoAct-1 (56.39%), Agent S2.5 w/ o3 (54.21%), and Jedi-7B w/ o3 (50.65%). This represents a meaningful advancement in desktop automation capabilities, particularly considering the challenging nature of OSWorld tasks.

[Table 2](https://arxiv.org/html/2509.11067v1#S4.T2) provides detailed breakdowns across application categories, revealing where our orchestration approach provides the most significant advantages. Agentic Lybic demonstrates strong performance across most application categories, with particularly notable results in Chrome browser tasks (60.78% vs. CoAct-1’s 45.57%), LibreOffice Impress presentations (59.48% vs. CoAct-1’s 46.72%), GIMP image editing (84.62% vs. CoAct-1’s 61.54%), and OS-level operations (79.17% vs. CoAct-1’s 70.83%).

### **4.3.Efficiency Analysis**

Beyond success rates, Agentic Lybic demonstrates remarkable efficiency improvements through intelligent orchestration. Our system reduces the average number of steps required for task completion while maintaining higher success rates, indicating more effective task execution strategies. The tiered reasoning approach enables the system to select optimal execution modalities for each subtask, avoiding inefficient GUI manipulation sequences when programmatic approaches are more suitable.

Figure 3.OSWorld benchmark task complexity analysis. (a) Step count frequency distribution showing task completion requirements across the dataset. The distribution reveals the diverse complexity range in OSWorld tasks, from simple atomic operations to complex multi-step workflows. (b) Task category distribution across the 361 OSWorld tasks, showing multi-application workflows comprise the largest portion (93 tasks, 25.2% with average 27.3 steps), followed by LibreOffice applications (Calc: 47 tasks with 28.0 steps, Impress: 47 tasks with 28.0 steps, Writer: 23 tasks with 25.3 steps), Chrome browser tasks (46 tasks, 17.5 steps), and other specialized applications including GIMP (26 tasks, 20.9 steps), VS Code (23 tasks, 14.3 steps), OS operations (24 tasks, 8.8 steps), VLC (17 tasks, 10.7 steps), and Thunderbird (15 tasks, 16.7 steps).

The OSWorld benchmark presents diverse complexity challenges that highlight the effectiveness of our orchestration approach (Figure [3](https://arxiv.org/html/2509.11067v1#S4.F3)). The task complexity analysis reveals a heterogeneous distribution with 361 tasks ranging from simple atomic operations (0-4 steps, 70 tasks) to complex multi-step workflows (45-50 steps, 93 tasks), with an average of 22.31 steps per task. The task category distribution (Figure [3](https://arxiv.org/html/2509.11067v1#S4.F3)b) shows that multi-application workflows comprise the largest portion (93 tasks, 25.2% with average 27.3 steps), followed by LibreOffice applications, Chrome browser tasks, and specialized tools. This complexity distribution demonstrates why sophisticated orchestration mechanisms are essential—simple GUI-only approaches may suffice for atomic operations, but complex workflows requiring 25+ steps (representing 38.8% of all tasks) benefit significantly from our multi-modal coordination capabilities.

The quality gate system contributes significantly to efficiency by enabling early detection of execution issues and proactive course correction, preventing costly error propagation that typically requires extensive recovery procedures in other systems. Our periodic checks (every 5 steps), stagnation detection (3 consecutive identical actions), and success verification mechanisms ensure optimal resource utilization while maintaining robustness.

### **4.4.Error Analysis and Robustness**

Analysis of failure cases reveals that Agentic Lybic maintains robustness across diverse error conditions while highlighting both system limitations and evaluation challenges.

**Evaluation Standard Limitations.** A significant portion of observed failures stem from overly rigid evaluation criteria rather than actual system deficiencies. For instance, in a calculation task requiring multiplication of total work hours by hourly rate, our agent correctly computed the result but formatted it to two decimal places, while the gold standard required exactly four decimal places for acceptance. Similarly, in a presentation-to-video conversion task, our agent successfully exported slides to PNG format and encoded them into MP4 using ffmpeg, yet failed evaluation because the gold standard incorrectly marked this task as impossible to complete, as shown in Figure [A.1](https://arxiv.org/html/2509.11067v1#A2.F1). These cases highlight the need for more flexible evaluation frameworks that assess functional correctness rather than rigid formatting requirements.

**System Robustness Indicators.** Despite these challenges, Agentic Lybic demonstrates superior error handling compared to baseline methods. The system’s multi-modal execution strategy proves particularly effective in complex scenarios requiring seamless coordination across multiple applications. Figure [A.2](https://arxiv.org/html/2509.11067v1#A2.F2) illustrates a representative successful case where the agent handles a sophisticated multi-step workflow: extracting an AWS invoice PDF from a local email in the ”Bills” folder, moving it to the receipts folder while following existing file naming patterns, and updating a tally book record. This example showcases the agent’s capability to seamlessly coordinate across multiple applications (email client, file manager, spreadsheet) while maintaining context awareness for naming conventions and data entry patterns.

The incremental clarification policy effectively resolves visual ambiguities in GUI-dense environments, preventing accumulation of grounding errors that typically plague pure vision-based approaches. Stagnation detection triggers (activated after 3 consecutive identical actions) successfully prevent infinite loops, while periodic quality checks (every 5 steps) enable early intervention before critical failures occur. The tiered architecture enables graceful degradation when individual components encounter limitations. When the Operator struggles with visual grounding ambiguity, the system automatically transitions to Technician-based programmatic approaches where available. The Manager’s adaptive re-planning capabilities (light, medium, and heavy adjustment levels) provide multiple recovery strategies based on failure severity, ensuring robust performance across diverse failure conditions.

Our analysis demonstrates that while Agentic Lybic faces challenges inherent to complex desktop automation, the sophisticated coordination mechanisms and continuous quality control provide substantial improvements in both success rates and error recovery compared to existing approaches. The multi-modal execution strategy, combined with robust quality gates and adaptive re-planning, enables the system to handle diverse failure conditions while maintaining operational effectiveness across complex multi-application workflows.

## **5.Conclusion**

In this work, we introduced Agentic Lybic, a novel multi-agent execution system that addresses fundamental limitations in desktop automation through tiered reasoning architecture and sophisticated orchestration mechanisms. Our system advances beyond existing approaches by implementing a comprehensive four-tier framework comprising a Controller for state management, a Manager for intelligent task decomposition, specialized Workers for different execution modalities, and an Evaluator for continuous quality assessment.

The key innovation of our approach lies in the dynamic orchestration mechanism that seamlessly coordinates between GUI manipulation, system-level operations, and analytical decision-making based on real-time task assessment. Unlike previous systems that rely on static task delegation, Agentic Lybic implements continuous feedback loops through comprehensive quality gates, enabling adaptive re-planning and robust error recovery throughout task execution. This principled approach to multi-agent coordination, combined with specialized worker roles and incremental clarification policies, provides a more robust foundation for handling the inherent complexity of real-world desktop automation.

Our experimental evaluation on the challenging OSWorld benchmark demonstrates the effectiveness of this approach, achieving a new state-of-the-art success rate of 57.07% in 50 steps—a substantial improvement over existing methods including CoAct-1 (56.39%) and Agent S2.5 (54.21%). Beyond raw performance gains, our system exhibits superior reliability across diverse task categories. These results validate our hypothesis that principled orchestration with continuous quality control provides significant advantages over both pure GUI agents and simpler hybrid approaches.

Our approach has certain inherent constraints: real-time visual understanding for tasks like video editing or gaming with continuous visual changes, and scenarios requiring human verification such as CAPTCHAs or secure authentication processes. Additionally, highly specialized software domains may require deeper contextual knowledge than current models provide.

Our work opens several promising directions for future research. The tiered reasoning framework provides a systematic foundation for incorporating additional specialized components, such as domain-specific workers for complex applications like video editing software or development environments. The quality gate system could be extended with more sophisticated intervention strategies, potentially including predictive error detection and proactive resource allocation. Furthermore, the orchestration mechanisms could be adapted to handle collaborative multi-user scenarios or distributed computing environments.

As vision-language models continue advancing, our orchestration framework provides a flexible foundation for integrating new capabilities into more robust automation systems. The success of our approach suggests that the future of desktop automation lies in developing sophisticated coordination mechanisms that can orchestrate multiple specialized components in principled and adaptive ways, opening possibilities for truly autonomous computing assistants that handle diverse human-computer interaction tasks with reliability and efficiency.

## **References**

- (1)

- Agashe et al. (2024)

- Saaket Agashe, Jiuzhou Han, Shuyu Gan, Jiachen Yang, Ang Li, and Xin Eric Wang. 2024.Agent s: An open agentic framework that uses computers like a human.

- Agashe et al. (2025a)

- Saaket Agashe, Kyle Wong, Vincent Tu, Jiachen Yang, Ang Li, and Xin Eric Wang. 2025a.Agent S2: A Compositional Generalist-Specialist Framework for Computer Use Agents.arXiv:2504.00906 [cs.AI] [https://arxiv.org/abs/2504.00906](https://arxiv.org/abs/2504.00906)

- Agashe et al. (2025b)

- Saaket Agashe, Kyle Wong, Vincent Tu, Jiachen Yang, Ang Li, and Xin Eric Wang. 2025b.Agent s2: A compositional generalist-specialist framework for computer use agents.

- Anthropic (2025)

- Anthropic. 2025.*Claude 3.7 Sonnet and Claude Code*.Technical Report. Anthropic.[https://www.anthropic.com/news/claude-3-7-sonnet](https://www.anthropic.com/news/claude-3-7-sonnet)System Card.

- Anthropic (2025)

- Anthropic. 2025.*Claude Opus 4 **&** Claude Sonnet 4 System Card*.System Card. Anthropic.[https://www-cdn.anthropic.com/4263b940cabb546aa0e3283f35b686f4f3b2ff47.pdf](https://www-cdn.anthropic.com/4263b940cabb546aa0e3283f35b686f4f3b2ff47.pdf)Accessed 4 Aug 2025.

- Cheng et al. (2024)

- Kanzhi Cheng, Qiushi Sun, Yougang Chu, Fangzhi Xu, Yantao Li, Jianbing Zhang, and Zhiyong Wu. 2024.Seeclick: Harnessing gui grounding for advanced visual gui agents.

- Deepmind (2025)

- Deepmind. 2025.*Gemini 2.5: Our most intelligent AI model*.Technical Report. Deepmind.[https://blog.google/technology/google-deepmind/gemini-model-thinking-updates-march-2025/](https://blog.google/technology/google-deepmind/gemini-model-thinking-updates-march-2025/)

- Gou et al. (2024)

- Boyu Gou, Ruohan Wang, Boyuan Zheng, Yanan Xie, Cheng Chang, Yiheng Shu, Huan Sun, and Yu Su. 2024.Navigating the digital world as humans do: Universal visual grounding for gui agents.

- Hong et al. (2024)

- Wenyi Hong, Weihan Wang, Qingsong Lv, Jiazheng Xu, Wenmeng Yu, Junhui Ji, Yan Wang, Zihan Wang, Yuxiao Dong, Ming Ding, et al. 2024.Cogagent: A visual language model for gui agents.14281–14290 pages.

- Hu et al. (2024)

- Mengkang Hu, Tianxing Chen, Qiguang Chen, Yao Mu, Wenqi Shao, and Ping Luo. 2024.HiAgent: Hierarchical Working Memory Management for Solving Long-Horizon Agent Tasks with Large Language Model.arXiv:2408.09559 [cs.CL] [https://arxiv.org/abs/2408.09559](https://arxiv.org/abs/2408.09559)

- Huang et al. (2025)

- Jing Huang, Zhixiong Zeng, Wenkang Han, Yufeng Zhong, Liming Zheng, Shuai Fu, Jingyuan Chen, and Lin Ma. 2025.Scaletrack: Scaling and back-tracking automated gui agents.

- Lai et al. (2024)

- Hanyu Lai, Xiao Liu, Iat Long Iong, Shuntian Yao, Yuxuan Chen, Pengbo Shen, Hao Yu, Hanchen Zhang, Xiaohan Zhang, Yuxiao Dong, and Jie Tang. 2024.AutoWebGLM: A Large Language Model-based Web Navigating Agent.arXiv:2404.03648 [cs.CL] [https://arxiv.org/abs/2404.03648](https://arxiv.org/abs/2404.03648)

- Lai et al. (2025)

- Hanyu Lai, Xiao Liu, Yanxiao Zhao, Han Xu, Hanchen Zhang, Bohao Jing, Yanyu Ren, Shuntian Yao, Yuxiao Dong, and Jie Tang. 2025.ComputerRL: Scaling End-to-End Online Reinforcement Learning for Computer Use Agents.

- Li et al. (2025)

- Kaixin Li, Ziyang Meng, Hongzhan Lin, Ziyang Luo, Yuchen Tian, Jing Ma, Zhiyong Huang, and Tat-Seng Chua. 2025.Screenspot-pro: Gui grounding for professional high-resolution computer use.

- Liu et al. (2025a)

- Yuhang Liu, Pengxiang Li, Zishu Wei, Congkai Xie, Xueyu Hu, Xinchen Xu, Shengyu Zhang, Xiaotian Han, Hongxia Yang, and Fei Wu. 2025a.Infiguiagent: A multimodal generalist gui agent with native reasoning and reflection.

- Liu et al. (2025b)

- Yuhang Liu, Pengxiang Li, Congkai Xie, Xavier Hu, Xiaotian Han, Shengyu Zhang, Hongxia Yang, and Fei Wu. 2025b.Infigui-r1: Advancing multimodal gui agents from reactive actors to deliberative reasoners.

- Lu et al. (2024)

- Yadong Lu, Jianwei Yang, Yelong Shen, and Ahmed Awadallah. 2024.OmniParser for Pure Vision Based GUI Agent.arXiv:2408.00203 [cs.CV] [https://arxiv.org/abs/2408.00203](https://arxiv.org/abs/2408.00203)

- Luo et al. (2025)

- Run Luo, Lu Wang, Wanwei He, and Xiaobo Xia. 2025.Gui-r1: A generalist r1-style vision-language action model for gui agents.

- Nguyen et al. (2025)

- Dang Nguyen, Jian Chen, Yu Wang, Gang Wu, Namyong Park, Zhengmian Hu, Hanjia Lyu, Junda Wu, Ryan Aponte, Yu Xia, Xintong Li, Jing Shi, Hongjie Chen, Viet Dac Lai, Zhouhang Xie, Sungchul Kim, Ruiyi Zhang, Tong Yu, Mehrab Tanjim, Nesreen K. Ahmed, Puneet Mathur, Seunghyun Yoon, Lina Yao, Branislav Kveton, Thien Huu Nguyen, Trung Bui, Tianyi Zhou, Ryan A. Rossi, and Franck Dernoncourt. 2025.GUI Agents: A Survey.arXiv:2412.13501 [cs.AI] [https://arxiv.org/abs/2412.13501](https://arxiv.org/abs/2412.13501)

- OpenAI (2024)

- OpenAI. 2024.GPT-4o System Card.arXiv:2410.21276 [cs.CL]

- OpenAI (2025a)

- OpenAI. 2025a.Computer-Using Agent: Introducing a universal interface for AI to interact with the digital world.[https://openai.com/index/computer-using-agent](https://openai.com/index/computer-using-agent)

- OpenAI (2025b)

- OpenAI. 2025b.*OpenAI o3 and o4-mini System Card*.Technical Report. OpenAI.[https://cdn.openai.com/pdf/2221c875-02dc-4789-800b-e7758f3722c1/o3-and-o4-mini-system-card.pdf](https://cdn.openai.com/pdf/2221c875-02dc-4789-800b-e7758f3722c1/o3-and-o4-mini-system-card.pdf)System Card.

- Qin et al. (2025)

- Yujia Qin, Yining Ye, Junjie Fang, Haoming Wang, Shihao Liang, Shizuo Tian, Junda Zhang, Jiahao Li, Yunxin Li, Shijue Huang, et al. 2025.UI-TARS: Pioneering Automated GUI Interaction with Native Agents.

- Qiu et al. (2025)

- Jiahao Qiu, Xuan Qi, Tongcheng Zhang, Xinzhe Juan, Jiacheng Guo, Yifu Lu, Yimin Wang, Zixin Yao, Qihan Ren, Xun Jiang, et al. 2025.Alita: Generalist agent enabling scalable agentic reasoning with minimal predefinition and maximal self-evolution.

- Song et al. (2025)

- Linxin Song, Yutong Dai, Viraj Prabhu, Jieyu Zhang, Taiwei Shi, Li Li, Junnan Li, Silvio Savarese, Zeyuan Chen, Jieyu Zhao, Ran Xu, and Caiming Xiong. 2025.CoAct-1: Computer-using Agents with Coding as Actions.arXiv:2508.03923 [cs.CL] [https://arxiv.org/abs/2508.03923](https://arxiv.org/abs/2508.03923)

- Sun et al. (2025)

- Nan Sun, Bo Mao, Yongchang Li, Di Guo, and Huaping Liu. 2025.AssistantX: An LLM-Powered Proactive Assistant in Collaborative Human-Populated Environment.arXiv:2409.17655 [cs.RO] [https://arxiv.org/abs/2409.17655](https://arxiv.org/abs/2409.17655)

- Tallam (2025)

- Krti Tallam. 2025.From Autonomous Agents to Integrated Systems, A New Paradigm: Orchestrated Distributed Intelligence.arXiv:2503.13754 [eess.SY] [https://arxiv.org/abs/2503.13754](https://arxiv.org/abs/2503.13754)

- Tang et al. (2025)

- Liang Tang, Shuxian Li, Yuhao Cheng, Yukang Huo, Zhepeng Wang, Yiqiang Yan, Kaer Huang, Yanzhe Jing, and Tiaonan Duan. 2025.SEA: Self-Evolution Agent with Step-wise Reward for Computer Use.arXiv:2508.04037 [cs.AI] [https://arxiv.org/abs/2508.04037](https://arxiv.org/abs/2508.04037)

- Wang et al. (2025b)

- Haoming Wang, Haoyang Zou, Huatong Song, Jiazhan Feng, Junjie Fang, Junting Lu, Longxiang Liu, Qinyu Luo, Shihao Liang, Shijue Huang, Wanjun Zhong, Yining Ye, Yujia Qin, Yuwen Xiong, Yuxin Song, Zhiyong Wu, Aoyan Li, Bo Li, Chen Dun, Chong Liu, Daoguang Zan, Fuxing Leng, Hanbin Wang, Hao Yu, Haobin Chen, Hongyi Guo, Jing Su, Jingjia Huang, Kai Shen, Kaiyu Shi, Lin Yan, Peiyao Zhao, Pengfei Liu, Qinghao Ye, Renjie Zheng, Shulin Xin, Wayne Xin Zhao, Wen Heng, Wenhao Huang, Wenqian Wang, Xiaobo Qin, Yi Lin, Youbin Wu, Zehui Chen, Zihao Wang, Baoquan Zhong, Xinchun Zhang, Xujing Li, Yuanfan Li, Zhongkai Zhao, Chengquan Jiang, Faming Wu, Haotian Zhou, Jinlin Pang, Li Han, Qi Liu, Qianli Ma, Siyao Liu, Songhua Cai, Wenqi Fu, Xin Liu, Yaohui Wang, Zhi Zhang, Bo Zhou, Guoliang Li, Jiajun Shi, Jiale Yang, Jie Tang, Li Li, Qihua Han, Taoran Lu, Woyu Lin, Xiaokang Tong, Xinyao Li, Yichi Zhang, Yu Miao, Zhengxuan Jiang, Zili Li, Ziyuan Zhao, Chenxin Li, Dehua Ma, Feng Lin, Ge Zhang, Haihua Yang, Hangyu Guo, Hongda Zhu, Jiaheng Liu, Junda Du, Kai Cai, Kuanye Li, Lichen Yuan, Meilan Han, Minchao Wang, Shuyue Guo, Tianhao Cheng, Xiaobo Ma, Xiaojun Xiao, Xiaolong Huang, Xinjie Chen, Yidi Du, Yilin Chen, Yiwen Wang, Zhaojian Li, Zhenzhu Yang, Zhiyuan Zeng, Chaolin Jin, Chen Li, Hao Chen, Haoli Chen, Jian Chen, Qinghao Zhao, and Guang Shi. 2025b.UI-TARS-2 Technical Report: Advancing GUI Agent with Multi-Turn Reinforcement Learning.arXiv:2509.02544 [cs.AI] [https://arxiv.org/abs/2509.02544](https://arxiv.org/abs/2509.02544)

- Wang et al. (2025a)

- Xinyuan Wang, Bowen Wang, Dunjie Lu, Junlin Yang, Tianbao Xie, Junli Wang, Jiaqi Deng, Xiaole Guo, Yiheng Xu, Chen Henry Wu, et al. 2025a.Opencua: Open foundations for computer-use agents.

- Wu et al. (2024a)

- Qingyun Wu, Gagan Bansal, Jieyu Zhang, Yiran Wu, Beibin Li, Erkang Zhu, Li Jiang, Xiaoyun Zhang, Shaokun Zhang, Jiale Liu, et al. 2024a.Autogen: Enabling next-gen LLM applications via multi-agent conversations.

- Wu et al. (2024c)

- Zhiyong Wu, Zhenyu Wu, Fangzhi Xu, Yian Wang, Qiushi Sun, Chengyou Jia, Kanzhi Cheng, Zichen Ding, Liheng Chen, Paul Pu Liang, et al. 2024c.Os-atlas: A foundation action model for generalist gui agents.

- Wu et al. (2024b)

- Zhiyong Wu, Zhenyu Wu, Fangzhi Xu, Yian Wang, Qiushi Sun, Chengyou Jia, Kanzhi Cheng, Zichen Ding, Liheng Chen, Paul Pu Liang, and Yu Qiao. 2024b.OS-ATLAS: A Foundation Action Model for Generalist GUI Agents.arXiv:2410.23218 [cs.CL] [https://arxiv.org/abs/2410.23218](https://arxiv.org/abs/2410.23218)

- Xie et al. (2025)

- Tianbao Xie, Jiaqi Deng, Xiaochuan Li, Junlin Yang, Haoyuan Wu, Jixuan Chen, Wenjing Hu, Xinyuan Wang, Yuhui Xu, Zekun Wang, Yiheng Xu, Junli Wang, Doyen Sahoo, Tao Yu, and Caiming Xiong. 2025.Scaling Computer-Use Grounding via User Interface Decomposition and Synthesis.arXiv:2505.13227 [cs.AI] [https://arxiv.org/abs/2505.13227](https://arxiv.org/abs/2505.13227)

- Xie et al. (2024)

- Tianbao Xie, Danyang Zhang, Jixuan Chen, Xiaochuan Li, Siheng Zhao, Ruisheng Cao, Toh Jing Hua, Zhoujun Cheng, Dongchan Shin, Fangyu Lei, Yitao Liu, Yiheng Xu, Shuyan Zhou, Silvio Savarese, Caiming Xiong, Victor Zhong, and Tao Yu. 2024.OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments.arXiv:2404.07972 [cs.AI] [https://arxiv.org/abs/2404.07972](https://arxiv.org/abs/2404.07972)

- Xu et al. (2024)

- Yiheng Xu, Zekun Wang, Junli Wang, Dunjie Lu, Tianbao Xie, Amrita Saha, Doyen Sahoo, Tao Yu, and Caiming Xiong. 2024.Aguvis: Unified pure vision agents for autonomous gui interaction.

- Yang et al. (2025)

- Yan Yang, Dongxu Li, Yutong Dai, Yuhao Yang, Ziyang Luo, Zirui Zhao, Zhiyuan Hu, Junzhe Huang, Amrita Saha, Zeyuan Chen, Ran Xu, Liyuan Pan, Caiming Xiong, and Junnan Li. 2025.GTA1: GUI Test-time Scaling Agent.arXiv:2507.05791 [cs.AI] [https://arxiv.org/abs/2507.05791](https://arxiv.org/abs/2507.05791)

- Yang et al. (2024)

- Yuhao Yang, Yue Wang, Dongxu Li, Ziyang Luo, Bei Chen, Chao Huang, and Junnan Li. 2024.Aria-ui: Visual grounding for gui instructions.

- Ye et al. (2025)

- Jiabo Ye, Xi Zhang, Haiyang Xu, Haowei Liu, Junyang Wang, Zhaoqing Zhu, Ziwei Zheng, Feiyu Gao, Junjie Cao, Zhengxi Lu, Jitong Liao, Qi Zheng, Fei Huang, Jingren Zhou, and Ming Yan. 2025.Mobile-Agent-v3: Fundamental Agents for GUI Automation.arXiv:2508.15144 [cs.AI] [https://arxiv.org/abs/2508.15144](https://arxiv.org/abs/2508.15144)

- Yu et al. (2025)

- Wenwen Yu, Zhibo Yang, Jianqiang Wan, Sibo Song, Jun Tang, Wenqing Cheng, Yuliang Liu, and Xiang Bai. 2025.Omniparser v2: Structured-points-of-thought for unified visual text parsing and its generality to multimodal large language models.

- Zeng et al. (2025)

- Zhixiong Zeng, Jing Huang, Liming Zheng, Wenkang Han, Yufeng Zhong, Lei Chen, Longrong Yang, Yingjie Chu, Yuzhi He, and Lin Ma. 2025.UItron: Foundational GUI Agent with Advanced Perception and Planning.arXiv:2508.21767 [cs.CV] [https://arxiv.org/abs/2508.21767](https://arxiv.org/abs/2508.21767)

- Zhang et al. (2025a)

- Chaoyun Zhang, Shilin He, Jiaxu Qian, Bowen Li, Liqun Li, Si Qin, Yu Kang, Minghua Ma, Guyue Liu, Qingwei Lin, Saravan Rajmohan, Dongmei Zhang, and Qi Zhang. 2025a.Large Language Model-Brained GUI Agents: A Survey.arXiv:2411.18279 [cs.AI] [https://arxiv.org/abs/2411.18279](https://arxiv.org/abs/2411.18279)

- Zhang et al. (2025b)

- Chaoyun Zhang, He Huang, Chiming Ni, Jian Mu, Si Qin, Shilin He, Lu Wang, Fangkai Yang, Pu Zhao, Chao Du, et al. 2025b.Ufo2: The desktop agentos.

- Zhao et al. (2025)

- Shitian Zhao, Haoquan Zhang, Shaoheng Lin, Ming Li, Qilong Wu, Kaipeng Zhang, and Chen Wei. 2025.Pyvision: Agentic vision with dynamic tooling.

## **Appendix ASystem Trigger Codes**

This section provides a comprehensive overview of the trigger codes used in the Agentic Lybic system for state transitions and component coordination. These trigger codes enable precise tracking and debugging of system behavior across different execution phases.

### **A.1.Trigger Code Categories**

The Controller employs a comprehensive trigger code system that enables precise coordination between components and robust error handling. Each component in the system communicates with the Controller through specific trigger codes that indicate the current execution status and determine the next appropriate controller situation. The trigger system is organized into ten primary categories:

**Rule Validation** triggers implement the foundation of our automated quality control system, providing continuous oversight that prevents system degradation and ensures optimal resource utilization. The rule_quality_check_steps trigger enforces periodic assessment every 5 execution steps, creating a systematic evaluation rhythm that enables early detection of potential issues before they propagate into critical failures. When rule_quality_check_repeated_actions fires after detecting more than 3 identical consecutive actions, it indicates execution stagnation and immediately transitions the system to QUALITY_CHECK state, preventing infinite loops and resource waste on ineffective strategies. The rule_replan_long_execution trigger serves as an efficiency safeguard, activating when single subtask execution exceeds 15 actions to initiate strategic reconsideration through the REPLAN state, ensuring the system doesn’t persist with suboptimal approaches when more effective alternatives may exist.

Table A.1.Complete Trigger Code Reference for Agentic Lybic System

| **Category** | **Trigger Code** | **Description** | **Target State** |
| --- | --- | --- | --- |
| **Rule Validation** | rule_quality_check_steps | Periodic quality check every 5 steps | QUALITY_CHECK |
|  | rule_quality_check_repeated_actions | Triggered when identical actions repeated ¿3 times | QUALITY_CHECK |
|  | rule_replan_long_execution | Single subtask execution exceeds 15 actions | PLAN |
| **Task Status Rules** | rule_max_state_switches_reached | Maximum state switches exceeded | DONE |
|  | rule_plan_number_exceeded | Planning attempts exceed threshold | DONE |
|  | rule_state_switch_count_exceeded | State switch count limit reached | DONE |
|  | rule_task_completed | Task successfully completed | DONE |
|  | rule_task_runtime_exceeded | Task runtime limit exceeded | DONE |
| **INIT State** | subtask_ready | First subtask available for execution | GET_ACTION |
|  | no_subtasks | No subtasks available, need planning | PLAN |
|  | init_error | Error during initialization | PLAN |
| **GET_ACTION State** | no_current_subtask_id | Missing current subtask identifier | INIT |
|  | subtask_not_found | Referenced subtask not found | INIT |
|  | worker_success | Worker completed subtask successfully | QUALITY_CHECK |
|  | work_cannot_execute | Worker cannot execute current subtask | PLAN |
|  | worker_stale_progress | Worker progress stagnated | QUALITY_CHECK |
|  | worker_supplement | Worker requires additional information | SUPPLEMENT |
|  | worker_generate_action | Worker generated new action | EXECUTE_ACTION |
|  | no_worker_decision | No decision from worker | PLAN |
|  | get_action_error | Error during action generation | PLAN |
| **EXECUTE_ACTION** | execution_error | Error during action execution | GET_ACTION |
|  | command_completed | Command executed successfully | GET_ACTION |
|  | no_command | No command available for execution | GET_ACTION |
| **QUALITY_CHECK** | all_subtasks_completed | All subtasks finished | FINAL_CHECK |
|  | quality_check_passed | Quality assessment successful | GET_ACTION |
|  | quality_check_failed | Quality assessment failed | PLAN |
|  | quality_check_supplement | Additional info needed | SUPPLEMENT |
|  | quality_check_execute_action | Additional execution required | EXECUTE_ACTION |
|  | quality_check_error | Error during quality check | PLAN |
| **PLAN State** | subtask_ready_after_plan | New subtasks ready after planning | GET_ACTION |
|  | plan_error | Error during planning phase | INIT |
| **SUPPLEMENT** | supplement_completed | Information supplement finished | PLAN |
|  | supplement_error | Error during supplementation | PLAN |
| **FINAL_CHECK** | final_check_error | Error during final verification | DONE |
|  | final_check_pending | Additional subtasks discovered | GET_ACTION |
|  | final_check_passed | Final verification successful | DONE |
|  | final_check_failed | Final verification failed | PLAN |
|  | task_impossible | Task determined impossible | DONE |
| **Error Recovery** | unknown_state | Unrecognized system state | INIT |
|  | error_recovery | General error recovery | INIT |

**Task Status Rules** provide comprehensive system-wide oversight and resource management through monitoring mechanisms that enforce operational boundaries and detect completion conditions. These triggers collectively ensure that the system operates within defined computational limits while maintaining flexibility for complex task execution. The rule_max_state_switches_reached and rule_state_switch_count_exceeded triggers prevent excessive state transitions that could indicate system thrashing or infinite loops, terminating execution when predefined limits are exceeded. The rule_plan_number_exceeded trigger stops planning attempts that surpass configured thresholds (typically 10 attempts), preventing the system from consuming excessive resources on intractable planning problems. Task completion is managed through rule_task_completed, which signals successful fulfillment and transitions to the terminal DONE state, while rule_task_runtime_exceeded enforces temporal boundaries to ensure bounded execution regardless of task complexity.

**INIT State** triggers manage system initialization and task startup procedures, establishing the foundation for successful execution by ensuring proper system configuration and task availability. The subtask_ready trigger indicates that the Manager has successfully created initial subtasks and the system can proceed to action generation through GET_ACTION state. When no subtasks are available, the no_subtasks trigger redirects the system to REPLAN state, ensuring that execution cannot proceed without proper task decomposition. The init_error trigger handles initialization failures by transitioning to REPLAN state, enabling recovery from startup problems through strategy reconsideration and system reconfiguration.

**GET_ACTION State** triggers coordinate the critical interface between task planning and execution, managing communication with Worker components and handling the diverse outcomes of action generation attempts. The worker_success trigger signals successful subtask completion by any Worker component, immediately transitioning to QUALITY_CHECK state for verification and progress assessment. When Workers encounter execution difficulties, work_cannot_execute indicates their inability to handle the current subtask, triggering a transition to REPLAN state for strategic adjustment. The worker_stale_progress trigger detects execution stagnation and routes to QUALITY_CHECK for intervention, while worker_supplement requests additional information through SUPPLEMENT state transition. Successful action generation is confirmed by worker_generate_action, enabling progression to EXECUTE_ACTION state. Error conditions are handled through no_worker_decision and get_action_error, both triggering REPLAN state for recovery and strategy reassessment. Navigation errors are managed by no_current_subtask_id and subtask_not_found, which reset the system to INIT state for proper reinitialization.

**EXECUTE_ACTION** triggers manage the execution phase where generated actions are translated into actual system operations, providing essential feedback about command execution success and failure conditions. The command_completed trigger confirms successful action execution and returns control to GET_ACTION state for continuation with the next action in the sequence. When execution encounters problems, execution_error redirects back to GET_ACTION state, enabling the system to attempt alternative actions or request new action generation from Worker components. The no_command trigger handles cases where no executable command is available, returning to GET_ACTION state to ensure continuous progress and prevent execution stalls.

**QUALITY_CHECK** triggers implement comprehensive evaluation mechanisms that assess execution effectiveness and determine optimal continuation strategies based on current progress and system state. The all_subtasks_completed trigger recognizes task completion across all subtasks and transitions to FINAL_CHECK state for comprehensive verification. Successful progress continuation is managed by quality_check_passed, which returns to GET_ACTION state for next subtask execution. When quality assessment identifies problems, quality_check_failed triggers REPLAN state transition for strategic adjustment and recovery. Information gaps are addressed through quality_check_supplement, which activates SUPPLEMENT state for additional context gathering. Direct execution requirements are handled by quality_check_execute_action, enabling immediate transition to EXECUTE_ACTION state when additional operations are needed. Error conditions during quality assessment are managed by quality_check_error, triggering REPLAN state for system recovery and strategy reassessment.

**PLAN State** triggers manage the planning and re-planning processes, ensuring that task decomposition and strategic adjustment proceed effectively while handling planning failures gracefully. The subtask_ready_after_plan trigger indicates successful planning completion with new subtasks available for execution, enabling transition to GET_ACTION state to begin or resume task execution. Planning failures are handled by plan_error, which triggers INIT state transition for system reinitialization and recovery, ensuring that planning problems don’t propagate through the system and cause cascading failures.

**SUPPLEMENT** triggers coordinate information gathering and external resource integration, enabling the system to address knowledge gaps and ambiguous situations through additional context acquisition. The supplement_completed trigger signals successful information gathering and returns the system to REPLAN state, where the newly acquired information can be integrated into updated task strategies and decomposition. Supplementation failures are managed by supplement_error, which also transitions to REPLAN state, ensuring that information gathering problems are addressed through strategic reconsideration rather than system stalls.

**FINAL_CHECK** triggers implement comprehensive task verification and completion assessment, providing the final validation layer before task termination and handling discovery of additional requirements. The final_check_passed trigger confirms successful task completion according to all specified criteria and transitions to DONE state for system termination. When final verification reveals additional work requirements, final_check_pending redirects to GET_ACTION state for continued execution. Completion assessment failures are managed by final_check_failed, triggering REPLAN state for final strategy adjustment. The task_impossible trigger provides an explicit mechanism for recognizing intractable tasks, transitioning directly to DONE state to prevent infinite execution attempts. System errors during final verification are handled by final_check_error, also terminating in DONE state to ensure clean system shutdown.

**Error Recovery** triggers provide robust fault handling mechanisms that ensure system stability and graceful degradation under unexpected conditions or unrecognized states. The unknown_state trigger handles situations where the system encounters unrecognized or invalid states, providing a safe fallback by transitioning to INIT state for clean reinitialization. The general error_recovery trigger serves as a comprehensive safety mechanism for unexpected system errors, also redirecting to INIT state to ensure that unforeseen problems don’t cause system crashes or undefined behavior, instead enabling graceful recovery through controlled reinitialization.

This trigger-driven architecture ensures that Agentic Lybic maintains precise control over execution flow while providing the flexibility necessary for handling diverse desktop automation scenarios. The comprehensive trigger code system enables both fine-grained component coordination and robust system-wide oversight, contributing significantly to the system’s superior performance on complex long-horizon tasks.

## **Appendix BCase Study Analysis**

This section provides detailed analysis of representative success and failure cases to illustrate system behavior and evaluation challenges. Figure [A.1](https://arxiv.org/html/2509.11067v1#A2.F1) demonstrates instances where the system functionally succeeded but was marked as failed due to overly rigid evaluation standards, including a calculation task where correct computation was rejected for decimal formatting and a video conversion task that was completed successfully but deemed ”impossible” by the evaluator. These cases reveal important limitations in current benchmark evaluation methodologies that may underestimate actual system capabilities.

In contrast, Figure [A.2](https://arxiv.org/html/2509.11067v1#A2.F2) showcases a complex multi-modal workflow where Agentic Lybic demonstrates sophisticated coordination capabilities by seamlessly orchestrating operations across email client, file manager, and spreadsheet applications while maintaining contextual awareness for file naming conventions and data entry patterns. This successful case exemplifies the system’s ability to handle intricate cross-application workflows that require sustained coordination and context preservation across multiple execution phases.

Figure A.1.Failure case analysis demonstrating evaluation standard limitations. Task 1 shows a calculation task where the agent correctly computed the product of total hours and hourly rate but formatted the result to two decimal places, while the evaluation gold standard required four decimal places for correctness. Task 2 demonstrates a presentation-to-video conversion task where the agent successfully exported slides to PNG images and encoded them into an MP4 video using ffmpeg, but failed evaluation because the gold standard marked this task as impossible to complete. These cases highlight how rigid evaluation criteria can misclassify successful agent execution as failures.

Figure A.2.Successful case demonstrating multi-modal task execution. The task involves extracting an AWS invoice PDF from a local email in the ”Bills” folder, moving it to the receipts folder following existing file naming patterns, and updating a tally book record. This example showcases the agent’s capability to seamlessly coordinate across multiple applications (email client, file manager, spreadsheet) while maintaining context awareness for naming conventions and data entry patterns.